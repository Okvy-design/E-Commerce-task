<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/home/login', 'Home::login');
$routes->get('/home/signup', 'Home::signup');
$routes->get('/home/about', 'Home::about');
$routes->get('/service', 'Home::service');
$routes->get('/profile', 'Profile::index', ['filter' => 'auth']);


